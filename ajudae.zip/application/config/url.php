<?php

$config['adm']          = 'adm/';
$config['templateAdm']  = 'templates/' . $config['adm'];
$config['urlLayoutAdm'] = '../../' . $config['templateAdm'] . 'layout';