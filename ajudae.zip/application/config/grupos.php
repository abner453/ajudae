<?php

$config['gruposId'] = array(
    'adm' => 1
);

