<?php

$config['tituloAdm'] = 'Ajudaê Administração';